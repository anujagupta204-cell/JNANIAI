# 🔧 Quick Fix Guide

If the page says **"This page isn't working"** or **"ERR_EMPTY_RESPONSE"**, it means the server process got stuck.

## ⚡ 1-Click Fix

1. Open a new terminal
2. Run this command to kill old processes:
   ```powershell
   taskkill /F /IM node.exe
   ```
3. Restart the server:
   ```powershell
   node server.js
   ```
4. Refresh the page!

## 🔍 Why did this happen?
Sometimes when closing the browser or terminal, the "node.exe" process stays running in the background and holds onto port 3000. When you try to start it again, it conflicts. Killing the old process fixes it immediately.

**Server Status:**
✅ Running at http://localhost:3000
